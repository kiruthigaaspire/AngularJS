/*var soap = require('soap');

var url = __dirname + "/Rataill-Customer-Karthik.WSDL";
var args = {name: 'value'};
soap.createClient(url, function(err, client) {
    console.log(client)
    /*client.MyFunction(args, function(err, result) {
        console.log(result);
    });
});*/


// get HTTP modules
var connect = require('connect'),
    http = require('http'),
    request = require('request'),
    server = connect();

// create a node-soap client
var soap = require('soap'),
    join = require('path').join,
    wsdlPath = join(__dirname,"Rataill-Customer-Karthik.WSDL"),
    username = 'eaiuser',
    password = 'Wipro$123',
    sessionType = 'None';

soap.createClient(wsdlPath, function(err, client) {
    if (err) {
      throw err;
    };
    var args = {}
    console.log(client)
    client1 = client.ART_spcRC_spcInbound_spcUpsert_spcMain.ART_spcRC_spcInbound_spcUpsert_spcMain;
    console.log(client1)
    client1.ART_spcRC_spcInbound_spcUpsert_spcMain(args, function(err, result) {
        console.log(err);
        console.log("result");
        console.log(result)
    }, {timeout:1800000});
    /*// create a REST router to forward to the node-soap client
    var serviceGenerator = require('node-siebel'),
        router = serviceGenerator(client).router;

    // connect the router and start the server
    server.use(connect.bodyParser());
    server.use(router);
    http.createServer(server).listen(4000);*/
});

